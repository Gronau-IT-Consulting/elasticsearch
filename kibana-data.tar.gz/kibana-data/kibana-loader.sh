#/bin/bash
elasticdump --input=bro-mapping.json --output=http://localhost:9200/@bro-meta --type=mapping
elasticdump --input=bro-data.json --output=http://localhost:9200/@bro-meta --type=data
elasticdump --input=kibana-mapping.json --output=http://localhost:9200/.kibana --type=mapping
elasticdump --input=kibana-data.json --output=http://localhost:9200/.kibana --type=data
elasticdump --input=skedler-mapping.json --output=http://localhost:9200/.skedler2 --type=mapping
elasticdump --input=skedler-data.json --output=http://localhost:9200/.skedler2 --type=data
elasticdump --input=411-mapping.json --output=http://localhost:9200/411_alerts_1 --type=mapping
